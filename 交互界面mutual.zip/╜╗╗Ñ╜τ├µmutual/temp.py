# -*- coding: utf-8 -*-
"""
Created on Sun Nov 24 15:23:01 2019

@author: 17704
"""
#导入所需要的库
import os
import sys
import skimage
from skimage import io
from PIL import ImageGrab
from PyQt5.QtCore import Qt
from PyQt5.QtGui import (QPainter, QPen)
from PyQt5.QtWidgets import (QApplication, QWidget)




#x、y是窗口出现的位置
#x_resize是窗口的宽、y_resize是窗口的高
x=150
y=150
x_resize = 500
y_resize = 500



 
class Example(QWidget):
 
    def __init__(self):
        super(Example, self).__init__()
     
      #resize设置宽高，move设置位置
        self.resize(x_resize, y_resize)
        self.move(x, y)
        self.setWindowTitle("手写板")
     
      #setMouseTracking设置为False，否则不按下鼠标时也会跟踪鼠标事件
        self.setMouseTracking(False)
        self.pos_xy = []
     
    def paintEvent(self, event):
        painter = QPainter()
        painter.begin(self)
        pen = QPen(Qt.black, 2, Qt.SolidLine)
        painter.setPen(pen)
    
        if len(self.pos_xy) > 1:
            point_start = self.pos_xy[0]
            for pos_tmp in self.pos_xy:
                point_end = pos_tmp
     
                if point_end == (-1, -1):
                    point_start = (-1, -1)
                    continue
                if point_start == (-1, -1):
                    point_start = point_end
                    continue
     
                painter.drawLine(point_start[0], point_start[1], point_end[0], point_end[1])
                point_start = point_end
        painter.end()
     
    def mouseMoveEvent(self, event):
      
      #中间变量pos_tmp提取当前点
        pos_tmp = (event.pos().x(), event.pos().y())
      #pos_tmp添加到self.pos_xy中
        self.pos_xy.append(pos_tmp)
        self.update()
     
    def mouseReleaseEvent(self, event):
        pos_test = (-1, -1)
        self.pos_xy.append(pos_test)
     
        self.update()
def mutual():
    app = QApplication(sys.argv)
    pyqt_learn = Example()
    pyqt_learn.show()
    app.exec_()
    bbox = (x+10,y+40,x+x_resize,y+y_resize)
    im = ImageGrab.grab(bbox)        
    im.save('img.jpg')
    img=io.imread('img.jpg')
    #print(img.shape)
    """
    改变图片的尺寸
    """
    #img = skimage.transform.resize(img, (64,64))
    io.imshow(img)
    if not os.path.exists('./trian'):
        os.mkdir('./trian')
    io.imsave('./trian/train.jpg',img)  
        
if __name__ == "__main__":
#    app = QApplication(sys.argv)
#    pyqt_learn = Example()
#    pyqt_learn.show()
#    app.exec_()
#    bbox = (x+10,y+40,x+x_resize,y+y_resize)
#    im = ImageGrab.grab(bbox)        
#    im.save('img.jpg')
#    img=io.imread('img.jpg')
#    io.imshow(img)
#    if not os.path.exists('./trian'):
#        os.mkdir('./trian')
#    io.imsave('./trian/train.jpg',img)
    mutual()
