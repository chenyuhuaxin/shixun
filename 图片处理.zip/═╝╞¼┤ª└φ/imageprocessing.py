# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 08:56:04 2019

@author: zhanglinglingling
"""

import cv2
import os
import re
import os.path
import numpy as np
from PIL import Image
from scipy import misc
import random
import scipy.misc
import scipy.signal
import scipy.ndimage
from matplotlib.font_manager import FontProperties
font_set = FontProperties(fname=r"c:\windows\fonts\simsun.ttc", size=10)

#py文件与图片文件夹在同一目录下
waypath = "./train"
pathway = "./test"
pathtrain = "./pngtrain/"
pathtest = "./pngtest/"
# =============================================================================
# savetrain = './png_train/'
# savetest = './png_test/'
# =============================================================================
 
def medium_filter(im, x, y, step):
    sum_s = []
    for k in range(-int(step / 2), int(step / 2) + 1):
        for m in range(-int(step / 2), int(step / 2) + 1):
            sum_s.append(im[x + k][y + m])
    sum_s.sort()
    return sum_s[(int(step * step / 2) + 1)]
 
 
def mean_filter(im, x, y, step):
    sum_s = 0
    for k in range(-int(step / 2), int(step / 2) + 1):
        for m in range(-int(step / 2), int(step / 2) + 1):
            sum_s += im[x + k][y + m] / (step * step)
    return sum_s
 
 
def convert_2d(r):
    n = 3
    # 3*3 滤波器, 每个系数都是 1/9
    window = np.ones((n, n)) / n ** 2
    # 使用滤波器卷积图像
    # mode = same 表示输出尺寸等于输入尺寸
    # boundary 表示采用对称边界条件处理图像边缘
    s = scipy.signal.convolve2d(r, window, mode='same', boundary='symm')
    return s.astype(np.uint8)
 
 
def convert_3d(r):
    s_dsplit = []
    for d in range(r.shape[2]):
        rr = r[:, :, d]
        ss = convert_2d(rr)
        s_dsplit.append(ss)
    s = np.dstack(s_dsplit)
    return s
 
 
def add_salt_noise(way,path):

    for (root,dirs,filenames) in os.walk(way):    
    #root:根目录地址
    #dirs：子文件夹名字
    #filename：图像的名字
# =============================================================================
#     print(root)
#     print(1)
#     print(dirs)
#     print(2)
#     print(filenames)
# =============================================================================
        for i in root:    
            for filename in filenames:
                pattern = re.compile(r'\d')        
                asm=",".join(map(str, pattern.findall(root)))
                asn= re.sub(r',','',asm)
                 #print(len(asn))
                asn.replace('\n','')
                 #生成存储调整大小后训练集图片的文件                
                if not os.path.exists(path):
                    os.makedirs(path)
        
                 #生成存储每一个图片的文件夹
                path_asn =path+asn               
                 #print(path_asn)                            
                 
                if not os.path.exists(path_asn):
                    os.makedirs(path_asn)
                image0 = cv2.imdecode(np.fromfile(root+"/"+filename, dtype=np.uint8),-1)
                img0 = cv2.resize(image0,(60,60),)#改变图像大小
                cv2.imencode('.png', img0,)[1].tofile(path_asn+ '/'+filename)              
                #print(path_asn)
                img = np.array(Image.open(path_asn+ '/'+filename))
                rows, cols, dims = img.shape
                R = np.mat(img[:, :, 0])
                G = np.mat(img[:, :, 1])
                B = np.mat(img[:, :, 2])
             
                Grey_sp = R * 0.299 + G * 0.587 + B * 0.114
                #Grey_gs = R * 0.299 + G * 0.587 + B * 0.114
             
                snr = 0.9
             
                noise_num = int((1 - snr) * rows * cols)
             
                for i in range(noise_num):
                    rand_x = random.randint(0, rows - 1)
                    rand_y = random.randint(0, cols - 1)
                    if random.randint(0, 1) == 0:
                        Grey_sp[rand_x, rand_y] = 0
                    else:
                        Grey_sp[rand_x, rand_y] = 255
                #给图像加入高斯噪声
# =============================================================================
#                 Grey_gs = Grey_gs + np.random.normal(0, 48, Grey_gs.shape)
#                 Grey_gs = Grey_gs - np.full(Grey_gs.shape, np.min(Grey_gs))
#                 Grey_gs = Grey_gs * 255 / np.max(Grey_gs)
#                 Grey_gs = Grey_gs.astype(np.uint8)
# =============================================================================
             
                # 中值滤波
                Grey_sp_mf = scipy.ndimage.median_filter(Grey_sp, (7, 7))
                #Grey_gs_mf = scipy.ndimage.median_filter(Grey_gs, (8, 8))高斯噪声
                misc.imsave(path_asn+'/'+filename, Grey_sp_mf)#中值滤波去除校验噪声      


def main():
    add_salt_noise(waypath,pathtrain)
    add_salt_noise(pathway,pathtest)

 
if __name__ == '__main__':
    main()

"""
如果需要转成灰度矩阵时，将image0 = cv2.imdecode(np.fromfile(root+"/"+filename, dtype=np.uint8),-1)中的-1改成cv2.IMREAD_GRAYSCALE，会生成灰度的多维数组
转换为一维数组，这个转换后好像是列向量img1 = image0.flatten()
转成行向量img2 = img1.reshape(1,-1) 
  
"""