# -*- coding: utf-8 -*-
"""
Created on Thu Nov  7 08:33:05 2019

@author: zhanglinglingling
"""
def cut_words(temp):
     import jieba#中文分词库
     import re
     #整理词库的格式
     wenben = re.sub("[1234567890\s+\.\!\/_；：,$%^*(+\"\']+|[+——！，。？、~@#￥%……&*（）]+", "", temp)#将特殊字符、数字等替换为空 
     seg_list = jieba.cut(wenben, cut_all=True)  # 全模式分词 可以把所有可以成词的词语扫描出来，但是不能避免歧义词语     
     lists = []
     for item in seg_list:
         lists.append(item)#将成词的词语存入列表
     return lists #返回成词的列表
# =============================================================================
#  """
#      统计词频的函数get_counts1(),参数lists为切好的词的列表
#      以词语为键，数量为值，统计各词语的数量
#      如果这个词在计数器中，那么就给这个数加一，不在就令计数器等于1开始计数
#  """
# =============================================================================
# =============================================================================
def get_counts1(lists):
      counts = {}#字典
      for item in lists:
          if item in counts:#判断键是否在字典中
              counts[item] += 1
          else:
              counts[item] = 1
      return counts#返回这个字典类型的计数器
  
 
def get_top_counts(counts):
     value_keys = sorted([(count, tz) for tz, count in counts.items()], reverse=True)#reverse=True为倒序排列
     result = {}
     for item in value_keys:
         result[item[1]] = item[0]
     return value_keys#得到按出现次数顺序排列的词语
     #return result  
# =============================================================================
#  """
#      词联想的函数，输入的参数为输入的词，然后根据词库，按照词频高低，
#      输出你想输入的词组，即词联想。词库为二字词语。
#  """
# =============================================================================
def get_lianxiang1(word):
     import re     
     wenzhang = re.sub("[1234567890\s+\.\!\/_；：,$%^*(+\"\']+|[+——！，。？、~@#￥%……&*（）]+", "", temp)
     a = cut_words(wenzhang)  # 分词
     b = get_counts1(a)  # 词频统计
     data = {}
     for i in range(len(wenzhang)):
         data[wenzhang[i]] = {}
         for key in get_counts1(a):
             try:
                 if wenzhang[i] == key[0]:
                     data[wenzhang[i]][key] = b[key]
             except:
                 pass
     if word in data:
         dic=data[word]
         a=get_top_counts(dic)
         b=[]
         for item in a:
             b.append(item[1])#添加联想到的词语到b数组
         # print(a)
         print("为您联想的几个词为：",b)
         # print("联想结果如下:\n",data[word])
# =============================================================================
#     else:
#           print("没有根据本篇文章，您输入的词的联想词！")
#           get_lianxiang1()
# =============================================================================

 
if __name__ == '__main__':
     temp = open('./ciku.txt')
     temp = temp.read()
     words = ['暴','学','张','爆','薄']
     for word in words:
         get_lianxiang1(word)  # 调用获取联想词的函数。
